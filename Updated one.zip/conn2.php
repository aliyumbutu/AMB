<?php
		$conn = mysqli_connect("localhost","root","", "dbase");
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}



?>