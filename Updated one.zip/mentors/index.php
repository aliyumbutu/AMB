<?php

$email = $_GET['mail'];

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Mento07</title>
</head>
<body>
	<h1><?php echo $email; ?></h1>
<h1>You are Welcome new Mentor</h1>
<h5>thanks for your Journey throught the Regitration Stages </h5>
	<H4>THE SYSTEM IS NOT FULLY BEAULDED AND YOUR PARNEL WILL BE AVAILABLE IN SOME DAYS 'AA BUTU'</H4>
<a href="../index.php">CLICK HERE TO BACK TO MAIN PAGE</a>
</body>
</html>