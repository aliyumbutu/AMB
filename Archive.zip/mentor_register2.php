
<?php
	//start PHP session
	session_start();
	

	//check if register form is submitted
	if(isset($_POST['submit'])){
		//assign variables to post values

		$full_name = $_POST['full_name'];
		$dob = $_POST['dob'];
		$gender = $_POST['gender'];
		$skill = $_POST['skill'];
		$description = $_POST['description'];
		$address = $_POST['address'];
		$phone = $_POST['phone'];
		$country = $_POST['country'];
		$e_duration = $_POST['e_duration'];
		$email = $_GET["email"];

	

	}



	try{

include 'conn.php';
			
			$stmt = $pdo->prepare('UPDATE mentors SET full_name = :full_name, WHERE email = :email');


		 
		$stmt->execute(['full_name' => $email]);
		

			echo $statement->rowCount() . 'Record Updates';

	}
	catch(PDOException $error){
		$error->getMessage();
	}
	

		?>