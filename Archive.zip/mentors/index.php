<?php session_start();

$email = $_SESSION['mail'];

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Mento07</title>
</head>
<body>
	<h1><?php echo $email; ?></h1>
<h1>You are Welcome new Mentor</h1>
<h5>thanks for your Journey throught the Regitration Stages </h5>
</body>
</html>